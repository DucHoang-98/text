package lab6;

public class Lab6Bai1 {
	
	public static void main(String[] args) {
		QuanLySinhVien ql = new QuanLySinhVien();
		ql.menu();	
	}
}
